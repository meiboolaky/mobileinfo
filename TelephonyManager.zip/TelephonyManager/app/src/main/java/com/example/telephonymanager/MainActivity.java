package com.example.telephonymanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView tv1;
    Button button;
    private TelephonyManager tm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv1 = findViewById(R.id.textView);
        button = findViewById(R.id.button);
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_PHONE_STATE,Manifest.permission.READ_PRECISE_PHONE_STATE}, PackageManager.PERMISSION_GRANTED);
         tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {

                    String info = "Phone Details : \n";
                    String error="";

                    try {
                        String IMEINumber = tm.getImei();
                        info += "\nIMEI Number : " + IMEINumber;
                    }catch(Exception e){
                        error+="\nCannot get IMEI Number";
                    }

                    try {
                        String subscriberID = tm.getMeid();
                        info += "\nSubscriber ID : " + subscriberID;
                    }catch (Exception e){
                        error+="\nCannot get Subscriber ID";
                    }

                    try {
                        String SIMSerialNumber = tm.getSimSerialNumber();
                        info += "\nSim serial Number : " + SIMSerialNumber;
                    }catch(Exception e){
                        error+="\nCannot get Sim Serial Number";
                        }

                    try {
                        String networkCountryISO = tm.getNetworkCountryIso();
                        info += "\nNetwork Country ISO : " + networkCountryISO;
                    }catch(Exception e){
                        error+="\nCannot get Network Country ISO";
                    }

                    try {
                        String SIMCountryISO = tm.getSimCountryIso();
                        info += "\nSIM Country ISO : " + SIMCountryISO;
                    }catch(Exception e){
                        error+="\nCannot get Sim Country iso";
                    }


                    if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {


                    }
                    try {
                        String softwareVersion = tm.getDeviceSoftwareVersion();
                        info += "\nSoftware Version : " + softwareVersion;
                    }catch(Exception e){
                        error+="\nCannot get Software Verison";
                    }

                    try {
                        String voiceMailNumber = tm.getVoiceMailNumber();
                        info += "\nVoice Mail Number : " + voiceMailNumber;
                    }catch(Exception e){
                        error+="\nCannot get Voice Mail Number";
                    }
                    String phonetype = "";

                    int phoneType=10;
                    try {
                        phoneType = tm.getPhoneType();

                    }catch(Exception e ){
                        error+="\nCannot get Roaming";
                    }

                    switch (phoneType) {
                        case (TelephonyManager.PHONE_TYPE_CDMA):
                            phonetype = "CDMA";
                            break;
                        case (TelephonyManager.PHONE_TYPE_GSM):
                            phonetype = "GSM";
                            break;
                        case (TelephonyManager.PHONE_TYPE_NONE):
                            phonetype = "None";
                            break;
                    }
                    info += "\nPhone Networrk type : " + phonetype;
                    try {
                        boolean isRoaming = tm.isNetworkRoaming();
                        info += "\nIs Roaming : " + isRoaming;
                    }catch (Exception e){
                        error+="\nCannot get Roaming";
                    }
                    tv1.setText(info +"\n"+ error);

                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
                }
            }
        });


    }
}